//
//  HQKJDataCenterController.h
//  Huaching_Energy
//
//  Created by rc on 2017/8/15.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "BaseViewController.h"

@interface HQKJDataCenterController : BaseViewController

@end
