//
//  HQKJHomeViewController.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/15.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJHomeViewController.h"
#import "HQKJBriefDataCustomCell.h"
#import "HQKJLastWeekCustomCell.h"
#import "HQKJThisMonthEnergyCustomCell.h"
#import "HQKJWarmingManageCustomCell.h"
#import "HQKJDeviceManageCustomCell.h"
#import "HQKJCustomCycleScrollView.h"

static NSString * const kBriefDataCellIdentifier = @"kBriefDataCellIdentifier";
static NSString * const kLaskWeekCellIdentifier = @"kLaskWeekCellIdentifier";
static NSString * const kThisMonthEnergryCellIdentifier = @"kThisMonthEnergryCellInentifier";
static NSString * const kWarningManagementCellIdentifier = @"kWarningManagementCellIdentifier";
static NSString * const kDeviceManagementCellIdentifier = @"kDeviceManagementCellIdentifier";

@interface HQKJHomeViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic, strong) UITableView *tableView;
@property(nonatomic, strong) HQKJCustomCycleScrollView *cycleScrollView;
@end

@implementation HQKJHomeViewController

#pragma mark - Lazy loading

- (UITableView *)tableView {
    if (_tableView == nil) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[HQKJBriefDataCustomCell class] forCellReuseIdentifier:kBriefDataCellIdentifier];
        [_tableView registerClass:[HQKJLastWeekCustomCell class] forCellReuseIdentifier:kLaskWeekCellIdentifier];
        [_tableView registerClass:[HQKJThisMonthEnergyCustomCell class] forCellReuseIdentifier:kThisMonthEnergryCellIdentifier];
        [_tableView registerClass:[HQKJWarmingManageCustomCell class] forCellReuseIdentifier:kWarningManagementCellIdentifier];
        [_tableView registerClass:[HQKJDeviceManageCustomCell class] forCellReuseIdentifier:kDeviceManagementCellIdentifier];
    }
    return _tableView;
}

- (HQKJCustomCycleScrollView *)cycleScrollView {
    if (_cycleScrollView == nil) {
        _cycleScrollView = [[HQKJCustomCycleScrollView alloc]init];
    }
    return _cycleScrollView;
}

#pragma mark - Initialization Object

- (void)addInitilizationObjectsToView {
    
    [self.view addSubview:self.tableView];
}

#pragma mark - Instance Constraints

- (void)addConstraintsToAllInstances {
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top);
        make.left.equalTo(self.view.mas_left);
        make.right.equalTo(self.view.mas_right);
        make.bottom.equalTo(self.view.mas_bottom);
    }];
    
}


#pragma mark - Systom Methods

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationController.navigationBarHidden = YES;
    [self addInitilizationObjectsToView];
    [self addConstraintsToAllInstances];
    
}

#pragma mark - TableViewDelegate And TabelViewDataSource 

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 
    UITableViewCell *cell = nil;

    switch (indexPath.section) {
        case 0: {
            
             HQKJBriefDataCustomCell *briefDataCell = [tableView dequeueReusableCellWithIdentifier:kBriefDataCellIdentifier forIndexPath:indexPath];
            cell = briefDataCell;
            break;
        }
        case 1: {
            
            HQKJLastWeekCustomCell *lastWeekCell = [tableView dequeueReusableCellWithIdentifier:kLaskWeekCellIdentifier forIndexPath:indexPath];
            cell = lastWeekCell;
            break;
        }
        case 2: {
            
            HQKJThisMonthEnergyCustomCell *thisMonthCell = [tableView dequeueReusableCellWithIdentifier:kThisMonthEnergryCellIdentifier forIndexPath:indexPath];
            cell = thisMonthCell;
            break;
        }
        case 3: {
            HQKJWarmingManageCustomCell *warningManageCell = [tableView dequeueReusableCellWithIdentifier:kWarningManagementCellIdentifier forIndexPath:indexPath];
            cell = warningManageCell;
            break;
        }
        case 4: {
            HQKJDeviceManageCustomCell *deviceManageCell = [tableView dequeueReusableCellWithIdentifier:kDeviceManagementCellIdentifier forIndexPath:indexPath];
            cell = deviceManageCell;
            break;
        }
        default:
            break;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    CGFloat customCellHeight = 0;
    switch (indexPath.section) {
        case 0:
        {
            customCellHeight = HQKJ_ScreenAutoLayoutHeight(170);
           break;
        }
        case 1: {
            customCellHeight = HQKJ_ScreenAutoLayoutHeight(185);
            break;
        }
        case 2: {
            customCellHeight = HQKJ_ScreenAutoLayoutHeight(185);
            break;
        }
        case 3: {
            customCellHeight = HQKJ_ScreenAutoLayoutHeight(107);
            break;
        }
        case 4: {
            customCellHeight = HQKJ_ScreenAutoLayoutHeight(107);
            break;
        }
        default:
            break;
    }
    return customCellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {

    CGFloat headerHeight = 0.0;
    switch (section) {
        case 0:
        {
            headerHeight = HQKJ_ScreenAutoLayoutHeight(210);
            break;
        }
        case 1:
        case 2:
        case 3:
        case 4:
        {
            headerHeight = HQKJ_ScreenAutoLayoutHeight(10);
            break;
        }
        default:
            break;
    }
    return headerHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return self.cycleScrollView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
