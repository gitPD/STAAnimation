//
//  HQKJDeviceManageCustomCell.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/16.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJDeviceManageCustomCell.h"

@interface HQKJDeviceManageCustomCell ()
@property(nonatomic, strong) UILabel    *devicingManagerLable;
@property(nonatomic, strong) UILabel    *collectorLable;                //采集器
@property(nonatomic, strong) UILabel    *collectorNormalNumber;
@property(nonatomic, strong) UILabel    *collectorNormalText;
@property(nonatomic, strong) UILabel    *conllectorAbNormalNumber;
@property(nonatomic, strong) UILabel    *collectorAbnormalText;
@property(nonatomic, strong) UIView     *dividingViewFirst;             //分割线
@property(nonatomic, strong) UILabel    *acquistionTerminalLabel;       //采集终端
@property(nonatomic, strong) UILabel    *terminalNormalNumber;
@property(nonatomic, strong) UILabel    *terminalNormalText;
@property(nonatomic, strong) UILabel    *terminalAbnormalNumber;
@property(nonatomic, strong) UILabel    *terminalAbnormalText;
@property(nonatomic, strong) UIView     *dividingViewSecond;            //分割线
@property(nonatomic, strong) UILabel    *measureDeviceLable;            //计量设备
@property(nonatomic, strong) UILabel    *measureDeviceNormalNumber;
@property(nonatomic, strong) UILabel    *measureDeviceNormalText;
@property(nonatomic, strong) UILabel    *measureDeviceAbNormalNumber;
@property(nonatomic, strong) UILabel    *measureDeviceABNormalText;

@end

@implementation HQKJDeviceManageCustomCell

#pragma mark - Lazy Loading
- (UILabel *)devicingManagerLable {
    if (_devicingManagerLable == nil) {
        _devicingManagerLable = [[UILabel alloc]init];
        _devicingManagerLable.text = @"设备管理";
        _devicingManagerLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _devicingManagerLable.font = [UIFont fontWithCustomDefaultsize:14];
    }
    return _devicingManagerLable;
}

- (UILabel *)collectorLable {
    if (_collectorLable == nil) {
        _collectorLable = [[UILabel alloc]init];
        _collectorLable.text = @"采集器";
        _collectorLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
        _collectorLable.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _collectorLable;
}

- (UILabel *)collectorNormalNumber {
    if (_collectorNormalNumber == nil) {
        _collectorNormalNumber = [[UILabel alloc]init];
        _collectorNormalNumber.text = @"17";
        _collectorNormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _collectorNormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _collectorNormalNumber;
}

- (UILabel *)collectorNormalText {
    if (_collectorNormalText == nil) {
        _collectorNormalText = [[UILabel alloc]init];
        _collectorNormalText.text = @"正常";
        _collectorNormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _collectorNormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _collectorNormalText;
}

- (UILabel *)conllectorAbNormalNumber {
    if (_conllectorAbNormalNumber == nil) {
        _conllectorAbNormalNumber = [[UILabel alloc]init];
        _conllectorAbNormalNumber.text = @"0";
        _conllectorAbNormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _conllectorAbNormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _conllectorAbNormalNumber;
}

- (UILabel *)collectorAbnormalText {
    if (_collectorAbnormalText == nil) {
        _collectorAbnormalText = [[UILabel alloc]init];
        _collectorAbnormalText.text = @"异常";
        _collectorAbnormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _collectorAbnormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _collectorAbnormalText;
}

- (UIView *)dividingViewFirst {
    if (_dividingViewFirst == nil) {
        _dividingViewFirst = [[UIView alloc]init];
        _dividingViewFirst.backgroundColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
    }
    return _dividingViewFirst;
}

- (UILabel *)acquistionTerminalLabel {
    if (_acquistionTerminalLabel == nil) {
        _acquistionTerminalLabel = [[UILabel alloc]init];
        _acquistionTerminalLabel.text = @"采集终端";
        _acquistionTerminalLabel.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
        _acquistionTerminalLabel.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _acquistionTerminalLabel;
}

- (UILabel *)terminalNormalNumber {
    if (_terminalNormalNumber == nil) {
        _terminalNormalNumber = [[UILabel alloc]init];
        _terminalNormalNumber.text = @"17";
        _terminalNormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _terminalNormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _terminalNormalNumber;
}

- (UILabel *)terminalNormalText {
    if (_terminalNormalText == nil) {
        _terminalNormalText = [[UILabel alloc]init];
        _terminalNormalText.text = @"正常";
        _terminalNormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _terminalNormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _terminalNormalText;
}

- (UILabel *)terminalAbnormalNumber {
    if (_terminalAbnormalNumber == nil) {
        _terminalAbnormalNumber = [[UILabel alloc]init];
        _terminalAbnormalNumber.text = @"2";
        _terminalAbnormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _terminalAbnormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _terminalAbnormalNumber;
}

- (UILabel *)terminalAbnormalText {
    if (_terminalAbnormalText == nil) {
        _terminalAbnormalText = [[UILabel alloc]init];
        _terminalAbnormalText.text = @"异常";
        _terminalAbnormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _terminalAbnormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _terminalAbnormalText;
}

- (UIView *)dividingViewSecond {
    if (_dividingViewSecond == nil) {
        _dividingViewSecond = [[UIView alloc]init];
        _dividingViewSecond.backgroundColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
    }
    return _dividingViewSecond;
}

- (UILabel *)measureDeviceLable {
    if (_measureDeviceLable == nil) {
        _measureDeviceLable = [[UILabel alloc]init];
        _measureDeviceLable.text = @"计量设备";
        _measureDeviceLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
        _measureDeviceLable.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _measureDeviceLable;
}

- (UILabel *)measureDeviceNormalNumber {
    if (_measureDeviceNormalNumber == nil) {
        _measureDeviceNormalNumber = [[UILabel alloc]init];
        _measureDeviceNormalNumber.text = @"17";
        _measureDeviceNormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _measureDeviceNormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _measureDeviceNormalNumber;
}

- (UILabel *)measureDeviceNormalText {
    if (_measureDeviceNormalText == nil) {
        _measureDeviceNormalText = [[UILabel alloc]init];
        _measureDeviceNormalText.text = @"正常";
        _measureDeviceNormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _measureDeviceNormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _measureDeviceNormalText;
}

- (UILabel *)measureDeviceAbNormalNumber {
    if (_measureDeviceAbNormalNumber == nil) {
        _measureDeviceAbNormalNumber = [[UILabel alloc]init];
        _measureDeviceAbNormalNumber.text = @"2";
        _measureDeviceAbNormalNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _measureDeviceAbNormalNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _measureDeviceAbNormalNumber;
}

- (UILabel *)measureDeviceABNormalText {
    if (_measureDeviceABNormalText == nil) {
        _measureDeviceABNormalText = [[UILabel alloc]init];
        _measureDeviceABNormalText.text = @"异常";
        _measureDeviceABNormalText.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL alpha:1.0];
        _measureDeviceABNormalText.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _measureDeviceABNormalText;
}

#pragma mark - Private Methods

- (void)addViewToDeviceManageCell {
    
    //设备管理Title
    [self addSubview:self.devicingManagerLable];
    
    //采集器Subtitle
    [self addSubview:self.collectorLable];

    //采集器正常数据
    [self addSubview:self.collectorNormalNumber];

    //采集器正常数据说明Lable
    [self addSubview:self.collectorNormalText];

    //采集器异常数据
    [self addSubview:self.conllectorAbNormalNumber];

    //采集器异常说明Lable
    [self addSubview:self.collectorAbnormalText];

    //分割线First
    [self addSubview:self.dividingViewFirst];

    //采集终端Subtitle
    [self addSubview:self.acquistionTerminalLabel];

    //采集终端正常数据
    [self addSubview:self.terminalNormalNumber];

    //采集终端正常数据说明Lable
    [self addSubview:self.terminalNormalText];

    //采集终端异常数据
    [self addSubview:self.terminalAbnormalNumber];

    //采集终端异常数据说明Lable
    [self addSubview:self.terminalAbnormalText];

    //分割线Second
    [self addSubview:self.dividingViewSecond];

    //计量设备SubTitle
    [self addSubview:self.measureDeviceLable];

    //计量设备正常数据
    [self addSubview:self.measureDeviceNormalNumber];
    
    //计量设备正常数据说明Lable
    [self addSubview:self.measureDeviceNormalText];
    
    //计量设备异常数据
    [self addSubview:self.measureDeviceAbNormalNumber];
    
    //计量设备异常数据说明Lable
    [self addSubview:self.measureDeviceABNormalText];
}

- (void)addConstraintsToSubViews {
    
    //设备管理Title
    [self.devicingManagerLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(10));
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutWidth(10));
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(14));
    }];
    
    //采集器Subtitle
    [self.collectorLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.devicingManagerLable.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(11));
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutWidth(51));
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(10));
    }];
    
    //采集器正常数据
    [self.collectorNormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorLable.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(15));
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutWidth(33));
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(14));
    }];
    
    //采集器正常数据说明Lable
    [self.collectorNormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalNumber.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(4));
        make.centerX.equalTo(self.collectorNormalNumber);
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(18));
    }];
    
    //采集器异常数据
    [self.conllectorAbNormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalNumber.mas_top);
        make.left.equalTo(self.collectorNormalNumber.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(35));
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(14));
    }];
    
    //采集器异常说明Lable
    [self.collectorAbnormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalText.mas_top);
        make.centerX.equalTo(self.conllectorAbNormalNumber);
        make.height.equalTo(self.collectorNormalText.mas_height);
    }];
    
    //分割线First
    [self.dividingViewFirst mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(43));
        make.left.equalTo(self.collectorAbnormalText.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(26));
        make.size.mas_equalTo(CGSizeMake(HQKJ_ScreenAutoLayoutWidth(0.5), HQKJ_ScreenAutoLayoutHeight(43)));
    }];
    
    //采集终端Subtitle
    [self.acquistionTerminalLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorLable.mas_top);
        make.left.equalTo(self.dividingViewFirst.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(42));
        make.height.mas_equalTo(self.collectorLable.mas_height);
    }];
    
    //采集终端正常数据
    [self.terminalNormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalNumber.mas_top);
        make.left.equalTo(self.dividingViewFirst.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(29));
        make.height.mas_equalTo(self.collectorNormalNumber.mas_height);
    }];
    
    //采集终端正常数据说明Lable
    [self.terminalNormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalText.mas_top);
        make.centerX.equalTo(self.terminalNormalNumber);
        make.height.mas_equalTo(self.collectorNormalText);
    }];
    
    //采集终端异常数据
    [self.terminalAbnormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.terminalNormalNumber.mas_top);
        make.left.equalTo(self.terminalNormalNumber.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(35));
        make.height.mas_equalTo(self.terminalNormalNumber.mas_height);
    }];
    
    //采集终端异常数据说明Lable
    [self.terminalAbnormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.terminalNormalText.mas_top);
        make.centerX.equalTo(self.terminalAbnormalNumber);
        make.height.mas_equalTo(self.terminalNormalText);
    }];
    
    //分割线Second
    [self.dividingViewSecond mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.dividingViewFirst.mas_top);
        make.left.equalTo(self.terminalAbnormalText.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(26));
        make.height.mas_equalTo(self.dividingViewFirst.mas_height);
        make.width.mas_equalTo(self.dividingViewFirst.mas_width);
    }];
    
    //计量设备SubTitle
    [self.measureDeviceLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorLable.mas_top);
        make.left.equalTo(self.dividingViewSecond.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(42));
        make.height.mas_equalTo(self.collectorLable.mas_height);
    }];
    
    //计量设备正常数据
    [self.measureDeviceNormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalNumber.mas_top);
        make.left.equalTo(self.dividingViewSecond.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(24));
        make.height.equalTo(self.self.collectorNormalNumber.mas_height);
    }];
    
    //计量设备正常数据说明Lable
    [self.measureDeviceNormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.collectorNormalText.mas_top);
        make.centerX.equalTo(self.measureDeviceNormalNumber);
        make.height.mas_equalTo(self.collectorNormalText.mas_height);
    }];
    
    //计量设备异常数据
    [self.measureDeviceAbNormalNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.measureDeviceNormalNumber.mas_top);
        make.left.equalTo(self.measureDeviceNormalNumber.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(35));
        make.height.mas_equalTo(self.measureDeviceNormalNumber.mas_height);
    }];
    
    //计量设备异常数据说明Lable
    [self.measureDeviceABNormalText mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.measureDeviceNormalText.mas_top);
        make.centerX.equalTo(self.measureDeviceAbNormalNumber);
        make.height.mas_equalTo(self.collectorNormalText.mas_height);
    }];
}

#pragma mark - Systom Methods.

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    
        [self addViewToDeviceManageCell];
        [self addConstraintsToSubViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
