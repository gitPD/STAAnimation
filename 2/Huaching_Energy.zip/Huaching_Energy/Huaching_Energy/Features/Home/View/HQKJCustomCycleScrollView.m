//
//  HQKJCustomCycleScrollView.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/16.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJCustomCycleScrollView.h"

@interface HQKJCustomCycleScrollView ()

@end

@implementation HQKJCustomCycleScrollView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
