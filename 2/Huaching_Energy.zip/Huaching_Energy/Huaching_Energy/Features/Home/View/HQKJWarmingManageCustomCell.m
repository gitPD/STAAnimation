//
//  HQKJWarmingManageCustomCell.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/16.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJWarmingManageCustomCell.h"

@interface HQKJWarmingManageCustomCell ()
@property(nonatomic, strong) UILabel    *warningTitleLable;
@property(nonatomic, strong) UILabel    *thisYearLableNumber;
@property(nonatomic, strong) UILabel    *thisYearLable;
@property(nonatomic, strong) UIView     *dividingLineView;
@property(nonatomic, strong) UILabel    *thisMonthLableNumber;
@property(nonatomic, strong) UILabel    *thisMonthLable;
@property(nonatomic, strong) UIButton   *warningLogButton;

@end

@implementation HQKJWarmingManageCustomCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self addViewsToCell];
        [self addConstraintsToViews];
    }
    return self;
}

#pragma mark - Private Methods

- (void)addViewsToCell {
    
    // Title "报警管理"
    [self addSubview:self.warningTitleLable];
    
    //本年报警次数
    [self addSubview:self.thisYearLableNumber];
    
    //本年报警提示说明
    [self addSubview:self.thisYearLable];
    
    //分割线
    [self addSubview:self.dividingLineView];
    
    //本月报警次数
    [self addSubview:self.thisMonthLableNumber];
    
    //本月报警提示说明
    [self addSubview:self.thisMonthLable];
    
    //报警日志按钮
    [self addSubview:self.warningLogButton];
    
}

- (void)addConstraintsToViews {
    
    //Titile "报警管理"
    [self.warningTitleLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(10));
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutWidth(10));
    }];
    
    //本年报警次数
    [self.thisYearLableNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutWidth(76));
    }];
    
    //本年报警提示说明
    [self.thisYearLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.thisYearLableNumber.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(0));
        make.centerX.equalTo(self.thisYearLableNumber);
    }];
    
    //分割线
    [self.dividingLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.centerY.equalTo(self);
        make.size.mas_offset(CGSizeMake(HQKJ_ScreenAutoLayoutWidth(0.5), HQKJ_ScreenAutoLayoutHeight(43)));
    }];
    
    //本月报警次数
    [self.thisMonthLableNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self.dividingLineView).offset(HQKJ_ScreenAutoLayoutWidth(74));
    }];
    
    //本月报警提示说明
    [self.thisMonthLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.thisMonthLableNumber.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(0));
        make.centerX.equalTo(self.thisMonthLableNumber);
    }];
    
    //报警日志按钮
    [self.warningLogButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(10));
        make.right.equalTo(self.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(-13));
        make.size.mas_equalTo(CGSizeMake(HQKJ_ScreenAutoLayoutWidth(70), HQKJ_ScreenAutoLayoutHeight(11)));
    }];
    
}

#pragma mark - lazying Loading

- (UILabel *)warningTitleLable {
    if (_warningTitleLable == nil) {
        _warningTitleLable = [[UILabel alloc]init];
        _warningTitleLable.text = @"报警管理";
        _warningTitleLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _warningTitleLable.font = [UIFont fontWithCustomDefaultsize:14];
    }
    return _warningTitleLable;
}

- (UILabel *)thisYearLableNumber {
    if (_thisYearLableNumber == nil) {
        _thisYearLableNumber = [[UILabel alloc]init];
        _thisYearLableNumber.text = @"1125";
        _thisYearLableNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _thisYearLableNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _thisYearLableNumber;
}

- (UILabel *)thisYearLable {
    if (_thisYearLable == nil) {
        _thisYearLable = [[UILabel alloc]init];
        _thisYearLable.text = @"本年";
        _thisYearLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
        _thisYearLable.font = [UIFont fontWithCustomDefaultsize:12];
    }
    return _thisYearLable;
}

- (UIView *)dividingLineView {
    if (_dividingLineView == nil) {
        _dividingLineView = [[UIView alloc]init];
        _dividingLineView.backgroundColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
    }
    return _dividingLineView;
}

- (UILabel *)thisMonthLableNumber {
    if (_thisMonthLableNumber == nil) {
        _thisMonthLableNumber = [[UILabel alloc]init];
        _thisMonthLableNumber.text = @"106";
        _thisMonthLableNumber.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE alpha:1.0];
        _thisMonthLableNumber.font = [UIFont fontWithCustomDefaultsize:18];
    }
    return _thisMonthLableNumber;
}

- (UILabel *)thisMonthLable {
    if (_thisMonthLable == nil) {
        _thisMonthLable = [[UILabel alloc]init];
        _thisMonthLable.text = @"本月";
        _thisMonthLable.textColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
        _thisMonthLable.font = [UIFont fontWithCustomDefaultsize:12];
    }
    return _thisMonthLable;
}

- (UIButton *)warningLogButton {
    if (_warningLogButton == nil) {
        _warningLogButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _warningLogButton.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 0, HQKJ_ScreenAutoLayoutWidth(15));
        _warningLogButton.imageEdgeInsets = UIEdgeInsetsMake(0, HQKJ_ScreenAutoLayoutWidth(60), 0, 0);
        [_warningLogButton setImage:[UIImage imageNamed:@"icon_home_unfold"] forState:UIControlStateNormal];
        [_warningLogButton setTitle:@"报警日志" forState:UIControlStateNormal];
        [_warningLogButton setTitleColor:[UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG alpha:1.0] forState:UIControlStateNormal];
        _warningLogButton.titleLabel.font = [UIFont fontWithCustomDefaultsize:11];
    }
    return _warningLogButton;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
