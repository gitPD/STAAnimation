//
//  HQKJBriefDataCustomCell.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/16.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJBriefDataCustomCell.h"

@interface HQKJBriefDataCustomCell ()
@property(nonatomic, strong) UILabel        *totalEnergrySubtitle;             //总能耗
@property(nonatomic, strong) UILabel        *totalEnergryDuration;             //统计时长
@property(nonatomic, strong) UILabel        *totalEnergryNumber;
@property(nonatomic, strong) UIView         *dividingEnergryLine;              //能耗和功率分割线
@property(nonatomic, strong) UILabel        *totalPowerSubtitle;               //总功率
@property(nonatomic, strong) UILabel        *totalPowerNumber;
@property(nonatomic, strong) UILabel        *energryYearOnYearSubtitle;        //能耗同比
@property(nonatomic, strong) UILabel        *energryYearOnYearDuration;
@property(nonatomic, strong) UIImageView    *energryYearOnYearIndicate;        //指示图
@property(nonatomic, strong) UILabel        *energryYearOnYearNumber;
@property(nonatomic, strong) UIView         *dividingCompareLine;              //同比环比分割线
@property(nonatomic, strong) UILabel        *energryChainSubtitle;             //能耗环比
@property(nonatomic, strong) UILabel        *energryChainDuration;
@property(nonatomic, strong) UIImageView    *energryChainIndicate;             //指示图
@property(nonatomic, strong) UILabel        *energryChainNumber;
@end

@implementation HQKJBriefDataCustomCell

#pragma makr - Lazy Loading
- (UILabel *)totalEnergrySubtitle {
    if (_totalEnergrySubtitle == nil) {
        _totalEnergrySubtitle = [[UILabel alloc]init];
        [self setSubViewsWithLable:_totalEnergrySubtitle text: @"总能耗" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:14];
    }
    return _totalEnergrySubtitle;
}

- (UILabel *)totalEnergryDuration {
    if (_totalEnergryDuration == nil) {
        _totalEnergryDuration = [[UILabel alloc]init];
        [self setSubViewsWithLable:_totalEnergryDuration text:@"(本月)" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:10];
        
    }
    return _totalEnergryDuration;
}

- (UILabel *)totalEnergryNumber {
    if (_totalEnergryNumber == nil) {
        _totalEnergryNumber = [[UILabel alloc]init];
        [self setSubViewsWithLable:_totalEnergryNumber text:@"38228.53Kwh" textColor:HQKJ_HEXCOLOR_HOMEPAGE_BRIEFDATA_NUMBER textFont:20];
    }
    return _totalEnergryNumber;
}

- (UIView *)dividingEnergryLine {
    if (_dividingEnergryLine == nil) {
        _dividingEnergryLine = [[UIView alloc]init];
        _dividingEnergryLine.backgroundColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];;
    }
    return _dividingEnergryLine;
}

- (UILabel *)totalPowerSubtitle {
    if (_totalPowerSubtitle == nil) {
        _totalPowerSubtitle = [[UILabel alloc]init];
        [self setSubViewsWithLable:_totalPowerSubtitle text:@"总功率" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:14];
    }
    return _totalPowerSubtitle;
}

-(UILabel *)totalPowerNumber {
    if (_totalPowerNumber == nil) {
        _totalPowerNumber = [[UILabel alloc]init];
        [self setSubViewsWithLable:_totalPowerNumber text:@"3.00Kw" textColor:HQKJ_HEXCOLOR_HOMEPAGE_BRIEFDATA_NUMBER textFont:20];
    }
    return _totalPowerNumber;
}

- (UILabel *)energryYearOnYearSubtitle {
    if (_energryYearOnYearSubtitle == nil) {
        _energryYearOnYearSubtitle = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryYearOnYearSubtitle text:@"能耗同比" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:14];
    }
    return _energryYearOnYearSubtitle;
}

- (UILabel *)energryYearOnYearDuration {
    if (_energryYearOnYearDuration == nil) {
        _energryYearOnYearDuration = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryYearOnYearDuration text:@"(本月)" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:10];
    }
    return _energryYearOnYearDuration;
}

- (UIImageView *)energryYearOnYearIndicate {
    if (_energryYearOnYearIndicate == nil) {
        _energryYearOnYearIndicate = [[UIImageView alloc]init];
        _energryYearOnYearIndicate.image = [UIImage imageNamed:@"icon_home_up"];
    }
    return _energryYearOnYearIndicate;
}

- (UILabel *)energryYearOnYearNumber {
    if (_energryYearOnYearNumber == nil) {
        _energryYearOnYearNumber = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryYearOnYearNumber text:@"100%" textColor:HQKJ_HEXCOLOR_HOMEPAGE_BRIEFDATA_NUMBER textFont:20];
    }
    return _energryYearOnYearNumber;
}

- (UIView *)dividingCompareLine {
    if (_dividingCompareLine == nil) {
        _dividingCompareLine = [[UIView alloc]init];
        _dividingCompareLine.backgroundColor = [UIColor colorWithHexString:HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE alpha:1.0];
    }
    return _dividingCompareLine;
}

- (UILabel *)energryChainSubtitle {
    if (_energryChainSubtitle == nil) {
        _energryChainSubtitle = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryChainSubtitle text:@"能耗环比" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:14];
    }
    return _energryChainSubtitle;
}

- (UILabel *)energryChainDuration {
    if (_energryChainDuration == nil) {
        _energryChainDuration = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryChainDuration text:@"(本月)" textColor:HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG textFont:10];
    }
    return _energryChainDuration;
}

- (UIImageView *)energryChainIndicate {
    if (_energryChainIndicate == nil) {
        _energryChainIndicate = [[UIImageView alloc]init];
        _energryChainIndicate.image = [UIImage imageNamed:@"icon_home_down"];
    }
    return _energryChainIndicate;
}

- (UILabel *)energryChainNumber {
    if (_energryChainNumber == nil) {
        _energryChainNumber = [[UILabel alloc]init];
        [self setSubViewsWithLable:_energryChainNumber text:@"20%" textColor:HQKJ_HEXCOLOR_HOMEPAGE_BRIEFDATA_NUMBER textFont:20];
    }
    return _energryChainNumber;
}

#pragma mark - Private Methods

- (void)setSubViewsWithLable:(UILabel *)subLable text:(NSString *)textString textColor:(NSString *)colorString textFont:(NSInteger)fontNumber {
    
    subLable.text = textString;
    subLable.textColor = [UIColor colorWithHexString:colorString alpha:1.0];
    subLable.font = [UIFont fontWithCustomDefaultsize:fontNumber];
}

- (void)addViewsToBriefDataCustomCell {
    
    //总能耗
    [self addSubview:self.totalEnergrySubtitle];
    
    //总能耗统计时长
    [self addSubview:self.totalEnergryDuration];
    
    //总能耗数据
    [self addSubview:self.totalEnergryNumber];
    
    //分割线
    [self addSubview:self.dividingEnergryLine];
    
    //总功率
    [self addSubview:self.totalPowerSubtitle];
    
    //总功率数据
    [self addSubview:self.totalPowerNumber];
    
    //能耗同比
    [self addSubview:self.energryYearOnYearSubtitle];
    
    //能耗统计时长
    [self addSubview:self.energryYearOnYearDuration];
    
    //指示箭头图
    [self addSubview:self.energryYearOnYearIndicate];
    
    //能耗同比数据
    [self addSubview:self.energryYearOnYearNumber];
    
    //分割线
    [self addSubview:self.dividingCompareLine];
    
    //能耗环比
    [self addSubview:self.energryChainSubtitle];
    
    //能耗环比统计时长
    [self addSubview:self.energryChainDuration];
    
    //环比指示图
    [self addSubview:self.energryChainIndicate];
    
    //环比指示数据
    [self addSubview:self.energryChainNumber];
    
}

- (void)addContraintsToContentSubViews {
    
    //总能耗
    [self.totalEnergrySubtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(13));
        make.centerX.mas_equalTo(-HQKJ_ScreenWidth/4);
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(14));
    }];
    
    //总能耗统计时长
    [self.totalEnergryDuration mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.totalEnergrySubtitle.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(2));
        make.centerX.equalTo(self.totalEnergrySubtitle);
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(10));
    }];
    
    //总能耗数据
    [self.totalEnergryNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.totalEnergryDuration.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(13));
        make.centerX.equalTo(self.totalEnergrySubtitle);
        make.height.mas_equalTo(HQKJ_ScreenAutoLayoutHeight(15));
    }];
    
    //分割线
    [self.dividingEnergryLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_top).offset(HQKJ_ScreenAutoLayoutHeight(20));
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(HQKJ_ScreenAutoLayoutWidth(0.5), HQKJ_ScreenAutoLayoutHeight(43)));
    }];
    
    //总功率
    [self.totalPowerSubtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.totalEnergrySubtitle);
        make.centerX.mas_equalTo(HQKJ_ScreenWidth/4);
        make.height.equalTo(self.totalEnergrySubtitle.mas_height);
    }];
    
    //总功率数据
    [self.totalPowerNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.totalPowerSubtitle.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(25));
        make.centerX.equalTo(self.totalPowerSubtitle);
        make.height.equalTo(self.totalEnergryNumber.mas_height);
    }];
    
    //能耗同比
    [self.energryYearOnYearSubtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.totalEnergryNumber.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(34));
        make.centerX.equalTo(self.totalEnergrySubtitle);
        make.height.equalTo(self.totalEnergrySubtitle.mas_height);
    }];
    
    //能耗统计时长
    [self.energryYearOnYearDuration mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearSubtitle.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(2));
        make.centerX.equalTo(self.energryYearOnYearSubtitle);
        make.height.equalTo(self.totalEnergryDuration.mas_height);
    }];
    
    //指示箭头图
    [self.energryYearOnYearIndicate mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearDuration.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(13));
        make.left.equalTo(self.mas_left).offset(HQKJ_ScreenAutoLayoutHeight(61));
        make.size.mas_equalTo(CGSizeMake(HQKJ_ScreenAutoLayoutHeight(14), HQKJ_ScreenAutoLayoutHeight(14)));
    }];
    
    //能耗同比数据
    [self.energryYearOnYearNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearIndicate);
        make.left.equalTo(self.energryYearOnYearIndicate.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(3));
        make.height.equalTo(self.totalEnergryNumber.mas_height);
    }];
    
    //分割线
    [self.dividingCompareLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.dividingEnergryLine.mas_bottom).offset(HQKJ_ScreenAutoLayoutHeight(42));
        make.centerX.equalTo(self);
        make.size.equalTo(self.dividingEnergryLine);
    }];
    
    //能耗环比
    [self.energryChainSubtitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearSubtitle.mas_top);
        make.centerX.equalTo(self.totalPowerSubtitle);
        make.height.equalTo(self.energryYearOnYearSubtitle);
    }];
    
    //能耗环比统计时长
    [self.energryChainDuration mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearDuration);
        make.centerX.equalTo(self.energryChainSubtitle);
        make.height.equalTo(self.energryYearOnYearDuration);
    }];
    
    //环比指示图
    [self.energryChainIndicate mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearIndicate);
        make.left.equalTo(self.dividingCompareLine.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(54));
        make.height.equalTo(self.energryYearOnYearIndicate);
    }];
    
    //环比指示数据
    [self.energryChainNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.energryYearOnYearNumber);
        make.left.equalTo(self.energryChainIndicate.mas_right).offset(HQKJ_ScreenAutoLayoutWidth(3));
        make.height.equalTo(self.energryYearOnYearNumber);
    }];
}

#pragma makr - Systom Methods

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    
        [self addViewsToBriefDataCustomCell];
        [self addContraintsToContentSubViews];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
