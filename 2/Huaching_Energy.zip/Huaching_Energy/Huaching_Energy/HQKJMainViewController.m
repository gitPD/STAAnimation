//
//  HQKJMainViewController.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/15.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "HQKJMainViewController.h"
#import "HQKJHomeViewController.h"
#import "HQKJDataCenterController.h"
#import "HQKJEnergyRankingController.h"
#import "HQKJMineController.h"

@interface HQKJMainViewController ()

@end

@implementation HQKJMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self addAllChildViewControllers];
}

#pragma mark - Private Methods

- (void)addAllChildViewControllers {
    
    HQKJHomeViewController *homeControlelr = [[HQKJHomeViewController alloc]init];
    [self addChildViewController:homeControlelr title:@"首页" imageNamed:@"icon_home_default" selectedImage:@"icon_homepage_pitch"];
    
    HQKJDataCenterController *centerController = [[HQKJDataCenterController alloc]init];
    [self addChildViewController:centerController title:@"数据中心" imageNamed:@"icon_data_default" selectedImage:@"icon_data_pitch"];
    
    HQKJEnergyRankingController *rankingController = [[HQKJEnergyRankingController alloc]init];
    [self addChildViewController:rankingController title:@"能耗排名" imageNamed:@"icon_energy_default" selectedImage:@"icon_energy_pitch"];

    HQKJMineController *mineController = [[HQKJMineController alloc]init];
    [self addChildViewController:mineController title:@"我的" imageNamed:@"icon_mine_default" selectedImage:@"icon_mine_pitch"];
    
}

// 添加某个 childViewController
- (void)addChildViewController:(UIViewController *)ViewController title:(NSString *)title imageNamed:(NSString *)imageNamed selectedImage:(NSString *) selectedImangeNamed
{
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:ViewController];
    // 如果同时有navigationbar 和 tabbar的时候最好分别设置它们的title
//    ViewController.navigationItem.title = title;
//    navigationController.tabBarItem.title = title;
    navigationController.tabBarItem.title = title;
    navigationController.tabBarItem.image = [UIImage imageNamed:imageNamed];
    navigationController.tabBarItem.selectedImage = [UIImage imageNamed:selectedImangeNamed];
    [self addChildViewController:navigationController];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
