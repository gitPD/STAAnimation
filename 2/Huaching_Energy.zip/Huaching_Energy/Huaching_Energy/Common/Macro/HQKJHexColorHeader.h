//
//  HQKJHexColorHeader.h
//  Huaching_Energy
//
//  Created by rc on 2017/8/17.
//  Copyright © 2017年 rc. All rights reserved.
//

#ifndef HQKJHexColorHeader_h
#define HQKJHexColorHeader_h

#pragma mark - HomePage 

#define HQKJ_HEXCOLOR_HOMEPAGE_CELLTITLE             @"#353535"           //首页cell中title说明字体颜色
#define HQKJ_HEXCOLOR_HOMEPAGE_SUBTITLE              @"#b0b0b0"           //首页cell中SubTitle说明字体颜色
#define HQKJ_HEXCOLOR_HOMEPAGE_WARMINGLOG            @"#707070"           //首页cell中"报警日志"文字提示颜色
#define HQKJ_HEXCOLOR_HOMEPAGE_ABNORMAL              @"#fea250"           //首页cell中"报警日志"异常文字颜色
#define HQKJ_HEXCOLOR_HOMEPAGE_BRIEFDATA_NUMBER      @"#40a3ff"           //首页cell中"能耗对比"中 数据颜色

#endif /* HQKJHexColorHeader_h */
