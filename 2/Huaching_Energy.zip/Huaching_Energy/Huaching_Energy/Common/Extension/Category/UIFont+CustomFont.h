//
//  UIFont+CustomDefaultFont.h
//  Huaching_Energy
//
//  Created by rc on 2017/8/17.
//  Copyright © 2017年 rc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIFont (CustomFont)

//设置定义默认字体为PingFang-SC-Medium (iOS 9 以上才有)
+ (nullable UIFont *)fontWithCustomDefaultsize:(CGFloat)fontSize;

@end
