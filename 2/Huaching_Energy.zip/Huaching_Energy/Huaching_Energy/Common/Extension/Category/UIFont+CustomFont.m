//
//  UIFont+CustomDefaultFont.m
//  Huaching_Energy
//
//  Created by rc on 2017/8/17.
//  Copyright © 2017年 rc. All rights reserved.
//

#import "UIFont+CustomFont.h"

@implementation UIFont (CustomFont)

+ (nullable UIFont *)fontWithCustomDefaultsize:(CGFloat)fontSize {
    
    return [UIFont fontWithName:@"PingFang-SC-Medium" size:fontSize];
}
@end
